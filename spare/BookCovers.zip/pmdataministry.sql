
-- ----------------------------
-- Table structure for `deputy_pm`
-- ----------------------------
DROP TABLE IF EXISTS `deputy_pm`;
CREATE TABLE `deputy_pm` (
  `min_nr` smallint(3) NOT NULL DEFAULT '0',
  `deputy_name` varchar(20) NOT NULL DEFAULT '',
  `party` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`min_nr`,`deputy_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of deputy_pm
-- ----------------------------
INSERT INTO `deputy_pm` VALUES ('1', 'Deakin A', 'Protectionist');
INSERT INTO `deputy_pm` VALUES ('2', 'Lyne W J', 'Protectionist');
INSERT INTO `deputy_pm` VALUES ('3', 'Hughes W M', 'Labor');
INSERT INTO `deputy_pm` VALUES ('4', 'McLean A', 'Protectionist');
INSERT INTO `deputy_pm` VALUES ('5', 'Isaacs I A', 'Protectionist');
INSERT INTO `deputy_pm` VALUES ('6', 'Hughes W M', 'Labor');
INSERT INTO `deputy_pm` VALUES ('7', 'Cook J', 'Free Trade');
INSERT INTO `deputy_pm` VALUES ('8', 'Hughes W M', 'Labor');
INSERT INTO `deputy_pm` VALUES ('9', 'Forrest J', 'Liberal');
INSERT INTO `deputy_pm` VALUES ('10', 'Hughes W M', 'Labor');
INSERT INTO `deputy_pm` VALUES ('11', 'Tudor F G', 'Labor');
INSERT INTO `deputy_pm` VALUES ('12', 'Pearce G F', 'National Labor');
INSERT INTO `deputy_pm` VALUES ('13', 'Cook J', 'Nationalist');
INSERT INTO `deputy_pm` VALUES ('14', 'Cook J', 'Nationalist');
INSERT INTO `deputy_pm` VALUES ('15', 'Page E C G', 'Country');
INSERT INTO `deputy_pm` VALUES ('16', 'Theodore E G', 'Labor');
INSERT INTO `deputy_pm` VALUES ('17', 'Latham J G', 'United Australia');
INSERT INTO `deputy_pm` VALUES ('18', 'Page E C G', 'Country');
INSERT INTO `deputy_pm` VALUES ('19', 'Hughes W M', 'United Australia');
INSERT INTO `deputy_pm` VALUES ('20', 'Hughes W M', 'United Australia');
INSERT INTO `deputy_pm` VALUES ('21', 'Cameron A G', 'Country');
INSERT INTO `deputy_pm` VALUES ('22', 'Fadden A W', 'Country');
INSERT INTO `deputy_pm` VALUES ('23', 'Menzies R G', 'United Australia');
INSERT INTO `deputy_pm` VALUES ('24', 'Forde F M', 'Labor');
INSERT INTO `deputy_pm` VALUES ('25', 'Forde F M', 'Labor');
INSERT INTO `deputy_pm` VALUES ('26', 'Chifley J B', 'Labor');
INSERT INTO `deputy_pm` VALUES ('27', 'Forde F M', 'Labor');
INSERT INTO `deputy_pm` VALUES ('28', 'Evatt H V', 'Labor');
INSERT INTO `deputy_pm` VALUES ('29', 'Fadden A W', 'Country');
INSERT INTO `deputy_pm` VALUES ('30', 'Fadden A W', 'Country');
INSERT INTO `deputy_pm` VALUES ('31', 'Fadden A W', 'Country');
INSERT INTO `deputy_pm` VALUES ('32', 'McEwen J', 'Country');
INSERT INTO `deputy_pm` VALUES ('33', 'McEwen J', 'Country');
INSERT INTO `deputy_pm` VALUES ('34', 'McEwen J', 'Country');
INSERT INTO `deputy_pm` VALUES ('35', 'McEwen J', 'Country');
INSERT INTO `deputy_pm` VALUES ('36', 'McMahon W', 'Liberal');
INSERT INTO `deputy_pm` VALUES ('37', 'McEwen J', 'Country');
INSERT INTO `deputy_pm` VALUES ('38', 'McEwen J', 'Country');
INSERT INTO `deputy_pm` VALUES ('39', 'McEwen J', 'Country');
INSERT INTO `deputy_pm` VALUES ('39', 'Anthony J D', 'Country');
INSERT INTO `deputy_pm` VALUES ('40', 'Anthony J D', 'Country');
INSERT INTO `deputy_pm` VALUES ('41', 'Barnard L H', 'Labor');
INSERT INTO `deputy_pm` VALUES ('42', 'Barnard L H', 'Labor');
INSERT INTO `deputy_pm` VALUES ('42', 'Cairns J', 'Labor');
INSERT INTO `deputy_pm` VALUES ('42', 'Crean F', 'Labor');
INSERT INTO `deputy_pm` VALUES ('43', 'Anthony J D', 'National Country');
INSERT INTO `deputy_pm` VALUES ('44', 'Anthony J D', 'National Country');
INSERT INTO `deputy_pm` VALUES ('45', 'Anthony J D', 'National Country');
INSERT INTO `deputy_pm` VALUES ('46', 'Anthony J D', 'National Country');
INSERT INTO `deputy_pm` VALUES ('47', 'Anthony J D', 'National Country');
INSERT INTO `deputy_pm` VALUES ('48', 'Bowen L', 'Labor');
INSERT INTO `deputy_pm` VALUES ('49', 'Bowen L', 'Labor');
INSERT INTO `deputy_pm` VALUES ('50', 'Bowen L', 'Labor');
INSERT INTO `deputy_pm` VALUES ('51', 'Keating P J', 'Labor');
INSERT INTO `deputy_pm` VALUES ('51', 'Howe B L', 'Labor');
INSERT INTO `deputy_pm` VALUES ('52', 'Howe B L', 'Labor');
INSERT INTO `deputy_pm` VALUES ('53', 'Howe B L', 'Labor');
INSERT INTO `deputy_pm` VALUES ('53', 'Beazley K', 'Labor');
INSERT INTO `deputy_pm` VALUES ('54', 'Fischer T', 'National');
INSERT INTO `deputy_pm` VALUES ('55', 'Fischer T', 'National');
INSERT INTO `deputy_pm` VALUES ('55', 'Anderson J', 'National');
INSERT INTO `deputy_pm` VALUES ('56', 'Gillard J', 'Labor');

-- ----------------------------
-- Table structure for `ministry`
-- ----------------------------
DROP TABLE IF EXISTS `ministry`;
CREATE TABLE `ministry` (
  `min_nr` smallint(3) NOT NULL DEFAULT '0',
  `pm_name` varchar(20) NOT NULL,
  `party` varchar(20) DEFAULT NULL,
  `day_comm` smallint(3) DEFAULT NULL,
  `mth_comm` smallint(3) DEFAULT NULL,
  `yr_comm` smallint(4) DEFAULT NULL,
  PRIMARY KEY (`min_nr`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of ministry
-- ----------------------------
INSERT INTO `ministry` VALUES ('1', 'Barton E', 'Protectionist', '1', '1', '1901');
INSERT INTO `ministry` VALUES ('2', 'Deakin A', 'Protectionist', '24', '9', '1903');
INSERT INTO `ministry` VALUES ('3', 'Watson J C', 'Labor', '27', '4', '1904');
INSERT INTO `ministry` VALUES ('4', 'Reid G H', 'Free Trade', '18', '8', '1904');
INSERT INTO `ministry` VALUES ('5', 'Deakin A', 'Protectionist', '5', '7', '1905');
INSERT INTO `ministry` VALUES ('6', 'Fisher A', 'Labor', '13', '11', '1908');
INSERT INTO `ministry` VALUES ('7', 'Deakin A', 'Protectionist', '2', '6', '1909');
INSERT INTO `ministry` VALUES ('8', 'Fisher A', 'Labor', '29', '4', '1910');
INSERT INTO `ministry` VALUES ('9', 'Cook J', 'Liberal', '24', '6', '1913');
INSERT INTO `ministry` VALUES ('10', 'Fisher A', 'Labor', '17', '9', '1914');
INSERT INTO `ministry` VALUES ('11', 'Hughes W M', 'Labor', '27', '10', '1915');
INSERT INTO `ministry` VALUES ('12', 'Hughes W M', 'National Labor', '14', '11', '1916');
INSERT INTO `ministry` VALUES ('13', 'Hughes W M', 'Nationalist', '17', '2', '1917');
INSERT INTO `ministry` VALUES ('14', 'Hughes W M', 'Nationalist', '10', '1', '1918');
INSERT INTO `ministry` VALUES ('15', 'Bruce S M', 'Nationalist', '9', '2', '1923');
INSERT INTO `ministry` VALUES ('16', 'Scullin J H', 'Labor', '22', '10', '1929');
INSERT INTO `ministry` VALUES ('17', 'Lyons J A', 'United Australia', '6', '1', '1932');
INSERT INTO `ministry` VALUES ('18', 'Lyons J A', 'United Australia', '7', '11', '1938');
INSERT INTO `ministry` VALUES ('19', 'Page E C G', 'Country', '7', '4', '1939');
INSERT INTO `ministry` VALUES ('20', 'Menzies R G', 'United Australia', '26', '4', '1939');
INSERT INTO `ministry` VALUES ('21', 'Menzies R G', 'United Australia', '14', '3', '1940');
INSERT INTO `ministry` VALUES ('22', 'Menzies R G', 'United Australia', '28', '10', '1940');
INSERT INTO `ministry` VALUES ('23', 'Fadden A W', 'Country', '29', '8', '1941');
INSERT INTO `ministry` VALUES ('24', 'Curtin J', 'Labor', '7', '10', '1941');
INSERT INTO `ministry` VALUES ('25', 'Curtin J', 'Labor', '21', '9', '1943');
INSERT INTO `ministry` VALUES ('26', 'Forde F M', 'Labor', '6', '7', '1945');
INSERT INTO `ministry` VALUES ('27', 'Chifley J B', 'Labor', '13', '7', '1945');
INSERT INTO `ministry` VALUES ('28', 'Chifley J B', 'Labor', '1', '11', '1946');
INSERT INTO `ministry` VALUES ('29', 'Menzies R G', 'Liberal', '19', '12', '1949');
INSERT INTO `ministry` VALUES ('30', 'Menzies R G', 'Liberal', '11', '5', '1951');
INSERT INTO `ministry` VALUES ('31', 'Menzies R G', 'Liberal', '11', '1', '1956');
INSERT INTO `ministry` VALUES ('32', 'Menzies R G', 'Liberal', '10', '12', '1958');
INSERT INTO `ministry` VALUES ('33', 'Menzies R G', 'Liberal', '18', '12', '1963');
INSERT INTO `ministry` VALUES ('34', 'Holt H E', 'Liberal', '26', '1', '1966');
INSERT INTO `ministry` VALUES ('35', 'Holt H E', 'Liberal', '14', '12', '1966');
INSERT INTO `ministry` VALUES ('36', 'McEwen J', 'Country', '19', '12', '1967');
INSERT INTO `ministry` VALUES ('37', 'Gorton J G', 'Liberal', '10', '1', '1968');
INSERT INTO `ministry` VALUES ('38', 'Gorton J G', 'Liberal', '28', '2', '1968');
INSERT INTO `ministry` VALUES ('39', 'Gorton J G', 'Liberal', '12', '11', '1969');
INSERT INTO `ministry` VALUES ('40', 'McMahon W', 'Liberal', '10', '3', '1971');
INSERT INTO `ministry` VALUES ('41', 'Whitlam E G', 'Labor', '5', '12', '1972');
INSERT INTO `ministry` VALUES ('42', 'Whitlam E G', 'Labor', '19', '12', '1972');
INSERT INTO `ministry` VALUES ('43', 'Fraser J M', 'Liberal', '11', '11', '1975');
INSERT INTO `ministry` VALUES ('44', 'Fraser J M', 'Liberal', '22', '12', '1975');
INSERT INTO `ministry` VALUES ('45', 'Fraser J M', 'Liberal', '20', '12', '1977');
INSERT INTO `ministry` VALUES ('46', 'Fraser J M', 'Liberal', '3', '11', '1980');
INSERT INTO `ministry` VALUES ('47', 'Fraser J M', 'Liberal', '7', '5', '1982');
INSERT INTO `ministry` VALUES ('48', 'Hawke R J L', 'Labor', '11', '3', '1983');
INSERT INTO `ministry` VALUES ('49', 'Hawke R J L', 'Labor', '7', '12', '1984');
INSERT INTO `ministry` VALUES ('50', 'Hawke R J L', 'Labor', '11', '7', '1987');
INSERT INTO `ministry` VALUES ('51', 'Hawke R J L', 'Labor', '4', '4', '1990');
INSERT INTO `ministry` VALUES ('52', 'Keating P J', 'Labor', '20', '12', '1991');
INSERT INTO `ministry` VALUES ('53', 'Keating P J', 'Labor', '24', '3', '1993');
INSERT INTO `ministry` VALUES ('54', 'Howard J W', 'Liberal', '11', '3', '1996');
INSERT INTO `ministry` VALUES ('55', 'Howard J W', 'Liberal', '21', '10', '1998');

-- ----------------------------
-- Table structure for `pm_marriage`
-- ----------------------------
DROP TABLE IF EXISTS `pm_marriage`;
CREATE TABLE `pm_marriage` (
  `pm_name` varchar(20) NOT NULL,
  `spouse_name` varchar(20) DEFAULT NULL,
  `mar_yr` smallint(4) NOT NULL DEFAULT '0',
  `pm_age` smallint(4) DEFAULT NULL,
  `nr_children` smallint(3) DEFAULT NULL,
  PRIMARY KEY (`pm_name`,`mar_yr`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of pm_marriage
-- ----------------------------
INSERT INTO `pm_marriage` VALUES ('Barton E', 'Ross J M', '1877', '28', '6');
INSERT INTO `pm_marriage` VALUES ('Bruce S M', 'Anderson E', '1913', '30', '0');
INSERT INTO `pm_marriage` VALUES ('Chifley J B', 'Mackenzie E', '1914', '29', '0');
INSERT INTO `pm_marriage` VALUES ('Cook J', 'Turner M', '1885', '25', '9');
INSERT INTO `pm_marriage` VALUES ('Curtin J', 'Needham E', '1917', '32', '2');
INSERT INTO `pm_marriage` VALUES ('Deakin A ', 'Browne E M', '1882', '26', '3');
INSERT INTO `pm_marriage` VALUES ('Fadden A W', 'Thornber I', '1916', '21', '4');
INSERT INTO `pm_marriage` VALUES ('Fisher A', 'Irvine M J', '1901', '39', '5');
INSERT INTO `pm_marriage` VALUES ('Forde F M', 'OReilly V C', '1925', '35', '4');
INSERT INTO `pm_marriage` VALUES ('Fraser J M', 'Beggs T', '1956', '26', '4');
INSERT INTO `pm_marriage` VALUES ('Gorton J G', 'Brown B', '1935', '23', '3');
INSERT INTO `pm_marriage` VALUES ('Hawke R J L', 'Masterson H', '1956', '26', '3');
INSERT INTO `pm_marriage` VALUES ('Hawke R J L', 'DAlpuget B', '1995', '65', '0');
INSERT INTO `pm_marriage` VALUES ('Holt H E', 'Fell Z K', '1946', '38', '3');
INSERT INTO `pm_marriage` VALUES ('Howard J W', 'Parker J', '1971', '31', '3');
INSERT INTO `pm_marriage` VALUES ('Hughes W M', 'Cutts E', '1890', '28', '6');
INSERT INTO `pm_marriage` VALUES ('Hughes W M', 'Campbell M E', '1911', '49', '1');
INSERT INTO `pm_marriage` VALUES ('Keating P J', 'Van Iersel A', '1975', '30', '4');
INSERT INTO `pm_marriage` VALUES ('Lyons J A', 'Burnell E M', '1915', '36', '11');
INSERT INTO `pm_marriage` VALUES ('McEwen J', 'McLeod A M', '1921', '21', '0');
INSERT INTO `pm_marriage` VALUES ('McEwen J', 'Byrne M', '1968', '68', '0');
INSERT INTO `pm_marriage` VALUES ('McMahon W', 'Hopkins S R', '1965', '57', '3');
INSERT INTO `pm_marriage` VALUES ('Menzies R G', 'Leckie P M', '1920', '26', '3');
INSERT INTO `pm_marriage` VALUES ('Page E C G', 'Blunt E', '1906', '26', '4');
INSERT INTO `pm_marriage` VALUES ('Reid G H', 'Bromby F', '1891', '46', '0');
INSERT INTO `pm_marriage` VALUES ('Scullin J H', 'McNamara M', '1907', '31', '0');
INSERT INTO `pm_marriage` VALUES ('Watson J C', 'Low A J', '1889', '22', '0');
INSERT INTO `pm_marriage` VALUES ('Watson J C', 'Lane A ', '1925', '58', '1');
INSERT INTO `pm_marriage` VALUES ('Whitlam E G', 'Dovey M E', '1942', '26', '4');
INSERT INTO `pm_marriage` VALUES ('Rudd', 'T', '0', null, null);
INSERT INTO `pm_marriage` VALUES ('Gillard', 'xxx', '0', null, null);

-- ----------------------------
-- Table structure for `pm_recreation`
-- ----------------------------
DROP TABLE IF EXISTS `pm_recreation`;
CREATE TABLE `pm_recreation` (
  `pm_name` varchar(20) NOT NULL,
  `recreation` varchar(20) NOT NULL,
  PRIMARY KEY (`pm_name`,`recreation`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of pm_recreation
-- ----------------------------
INSERT INTO `pm_recreation` VALUES (' Lyons J A', 'tennis');
INSERT INTO `pm_recreation` VALUES (' Menzies R G', 'cricket');
INSERT INTO `pm_recreation` VALUES ('Barton E', 'reading');
INSERT INTO `pm_recreation` VALUES ('Bruce S M', 'golf');
INSERT INTO `pm_recreation` VALUES ('Bruce S M', 'riding');
INSERT INTO `pm_recreation` VALUES ('Curtin J', 'swimming');
INSERT INTO `pm_recreation` VALUES ('Curtin J', 'walking');
INSERT INTO `pm_recreation` VALUES ('Deakin A', 'cycling');
INSERT INTO `pm_recreation` VALUES ('Deakin A', 'reading');
INSERT INTO `pm_recreation` VALUES ('Fadden A W', 'golf');
INSERT INTO `pm_recreation` VALUES ('Forde F M', 'golf');
INSERT INTO `pm_recreation` VALUES ('Forde F M', 'shooting');
INSERT INTO `pm_recreation` VALUES ('Forde F M', 'tennis');
INSERT INTO `pm_recreation` VALUES ('Fraser J M', 'fishing');
INSERT INTO `pm_recreation` VALUES ('Fraser J M', 'photography');
INSERT INTO `pm_recreation` VALUES ('Fraser J M', 'vintage cars');
INSERT INTO `pm_recreation` VALUES ('Gorton J G', 'reading');
INSERT INTO `pm_recreation` VALUES ('Hawke R J L', 'cricket');
INSERT INTO `pm_recreation` VALUES ('Hawke R J L', 'reading');
INSERT INTO `pm_recreation` VALUES ('Hawke R J L', 'tennis');
INSERT INTO `pm_recreation` VALUES ('Holt H E', 'golf');
INSERT INTO `pm_recreation` VALUES ('Holt H E', 'racing');
INSERT INTO `pm_recreation` VALUES ('Holt H E', 'spear fishing');
INSERT INTO `pm_recreation` VALUES ('Howard J W', 'cricket');
INSERT INTO `pm_recreation` VALUES ('Howard J W', 'films');
INSERT INTO `pm_recreation` VALUES ('Howard J W', 'reading');
INSERT INTO `pm_recreation` VALUES ('Hughes W M', 'golf');
INSERT INTO `pm_recreation` VALUES ('Hughes W M', 'motoring');
INSERT INTO `pm_recreation` VALUES ('Hughes W M', 'riding');
INSERT INTO `pm_recreation` VALUES ('Keating P J', 'antique clocks');
INSERT INTO `pm_recreation` VALUES ('Keating P J', 'sailing');
INSERT INTO `pm_recreation` VALUES ('Keating P J', 'vintage cars');
INSERT INTO `pm_recreation` VALUES ('McEwen J', 'farming');
INSERT INTO `pm_recreation` VALUES ('McEwen J', 'reading');
INSERT INTO `pm_recreation` VALUES ('McMahon W', 'golf');
INSERT INTO `pm_recreation` VALUES ('McMahon W', 'music');
INSERT INTO `pm_recreation` VALUES ('McMahon W', 'squash');
INSERT INTO `pm_recreation` VALUES ('Menzies R G', 'walking');
INSERT INTO `pm_recreation` VALUES ('Page E C G', 'tennis');
INSERT INTO `pm_recreation` VALUES ('Scullin J H', 'bowls');
INSERT INTO `pm_recreation` VALUES ('Scullin J H', 'reading');
INSERT INTO `pm_recreation` VALUES ('Scullin J H', 'walking');
INSERT INTO `pm_recreation` VALUES ('Watson J C', 'golf');
INSERT INTO `pm_recreation` VALUES ('Whitlam E G', 'music');
INSERT INTO `pm_recreation` VALUES ('Whitlam E G', 'swimming');
INSERT INTO `pm_recreation` VALUES ('Whitlam E G', 'theatre');

-- ----------------------------
-- Table structure for `prime_minister`
-- ----------------------------
DROP TABLE IF EXISTS `prime_minister`;
CREATE TABLE `prime_minister` (
  `pm_name` varchar(20) NOT NULL,
  `birth_yr` smallint(4) DEFAULT NULL,
  `yrs_served` decimal(4,0) DEFAULT NULL,
  `death_age` smallint(3) DEFAULT NULL,
  `state_born` varchar(3) DEFAULT NULL,
  `state_rep` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`pm_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of prime_minister
-- ----------------------------
INSERT INTO `prime_minister` VALUES ('Barton E', '1849', '3', '71', 'NSW', 'NSW');
INSERT INTO `prime_minister` VALUES ('Lyons J A', '1879', '7', '60', 'TAS', 'TAS');
INSERT INTO `prime_minister` VALUES ('Page E C G', '1880', '0', '81', 'NSW', 'NSW');
INSERT INTO `prime_minister` VALUES ('Menzies R G', '1894', '18', '84', 'VIC', 'VIC');
INSERT INTO `prime_minister` VALUES ('Fadden A W', '1895', '0', '78', 'QLD', 'QLD');
INSERT INTO `prime_minister` VALUES ('Curtin J', '1885', '4', '60', 'VIC', 'WA');
INSERT INTO `prime_minister` VALUES ('Forde F M', '1890', '0', '93', 'QLD', 'QLD');
INSERT INTO `prime_minister` VALUES ('Chifley J B', '1885', '4', '66', 'NSW', 'NSW');
INSERT INTO `prime_minister` VALUES ('Holt H E', '1908', '2', '59', 'NSW', 'VIC');
INSERT INTO `prime_minister` VALUES ('McEwen J', '1900', '0', '80', 'VIC', 'VIC');
INSERT INTO `prime_minister` VALUES ('Gorton J G', '1911', '3', null, 'VIC', 'VIC');
INSERT INTO `prime_minister` VALUES ('McMahon W', '1908', '2', '80', 'NSW', 'NSW');
INSERT INTO `prime_minister` VALUES ('Whitlam E G', '1916', '3', null, 'NSW', 'NSW');
INSERT INTO `prime_minister` VALUES ('Fraser J M', '1930', '7', null, 'VIC', 'VIC');
INSERT INTO `prime_minister` VALUES ('Hawke R J L', '1929', '9', null, 'SA', 'VIC');
INSERT INTO `prime_minister` VALUES ('Keating P J', '1944', '4', null, 'NSW', 'NS');
INSERT INTO `prime_minister` VALUES ('Howard J W', '1939', '11', null, 'NSW', 'NSW');
INSERT INTO `prime_minister` VALUES ('Rudd K', '1957', '3', null, 'QLD', 'QLD');
INSERT INTO `prime_minister` VALUES ('Gillard J', '1961', '3', null, 'QLD', 'QLD');

