<div class="newclass">
  <form  method="post" id="class">
    <input   class="form-control" id="classname" type="text" name="newclass"  placeholder="new class"  >
    <input type="button" name="button" value="ädd class" onClick="new_class()" >
  </form>
</div>
