
<legend>new lesson</legend>
<form  action="modle/lesson.php"  method="post" id="lesson">
 <input  class="form-control"  type="text" name="lessonname"  id="lessonname"> <br>
<input   class="form-control"  type="text" name="tutorial" id="tutorial" > <br>
<input type="submit" name="button" value="add lesson" >
</form>
