
<legend>new assignment</legend>
<form class="" action="modle/newassigment_process.php" method="post" enctype="multipart/form-data">
 <input  class="form-control"  type="text" name="conntent" required><br><br>
<input   class="form-control"  type="file" name="assignment"/><br><br>
<input type="submit" name="submit" value="Upload"></input>
</form>
