<?php include "../header.php" ?>

<h1>you are suspened </h1>


<a href="../../modle/logout.php" class="logout" > Logout</a>
